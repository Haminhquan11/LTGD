﻿
namespace BTH2
{
    partial class f1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb1 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb3 = new System.Windows.Forms.Label();
            this.groupBoxChon = new System.Windows.Forms.GroupBox();
            this.rd11 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.btQuaySo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbKetQua = new System.Windows.Forms.Label();
            this.groupBoxChon.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb1
            // 
            this.lb1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb1.Font = new System.Drawing.Font("Arial Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.ForeColor = System.Drawing.Color.Coral;
            this.lb1.Location = new System.Drawing.Point(148, 72);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(87, 112);
            this.lb1.TabIndex = 5;
            this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb2
            // 
            this.lb2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb2.Font = new System.Drawing.Font("Arial Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.ForeColor = System.Drawing.Color.Coral;
            this.lb2.Location = new System.Drawing.Point(309, 72);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(87, 112);
            this.lb2.TabIndex = 0;
            this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb3
            // 
            this.lb3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb3.Font = new System.Drawing.Font("Arial Narrow", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb3.ForeColor = System.Drawing.Color.Coral;
            this.lb3.Location = new System.Drawing.Point(483, 72);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(87, 112);
            this.lb3.TabIndex = 0;
            this.lb3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBoxChon
            // 
            this.groupBoxChon.Controls.Add(this.rd11);
            this.groupBoxChon.Controls.Add(this.rb3);
            this.groupBoxChon.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxChon.Location = new System.Drawing.Point(148, 220);
            this.groupBoxChon.Name = "groupBoxChon";
            this.groupBoxChon.Size = new System.Drawing.Size(422, 122);
            this.groupBoxChon.TabIndex = 1;
            this.groupBoxChon.TabStop = false;
            this.groupBoxChon.Text = "Chọn";
            // 
            // rd11
            // 
            this.rd11.Appearance = System.Windows.Forms.Appearance.Button;
            this.rd11.AutoSize = true;
            this.rd11.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.rd11.Location = new System.Drawing.Point(249, 51);
            this.rd11.Name = "rd11";
            this.rd11.Size = new System.Drawing.Size(85, 43);
            this.rd11.TabIndex = 1;
            this.rd11.Text = "11-18";
            this.rd11.UseVisualStyleBackColor = false;
            // 
            // rb3
            // 
            this.rb3.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3.AutoSize = true;
            this.rb3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.rb3.Checked = true;
            this.rb3.Location = new System.Drawing.Point(88, 51);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(72, 43);
            this.rb3.TabIndex = 0;
            this.rb3.TabStop = true;
            this.rb3.Text = "3-10";
            this.rb3.UseVisualStyleBackColor = false;
            // 
            // btQuaySo
            // 
            this.btQuaySo.AutoSize = true;
            this.btQuaySo.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQuaySo.Location = new System.Drawing.Point(148, 373);
            this.btQuaySo.Name = "btQuaySo";
            this.btQuaySo.Size = new System.Drawing.Size(116, 43);
            this.btQuaySo.TabIndex = 2;
            this.btQuaySo.Text = "Quay số";
            this.btQuaySo.UseVisualStyleBackColor = true;
            this.btQuaySo.Click += new System.EventHandler(this.btQuaySo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(413, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 33);
            this.label1.TabIndex = 3;
            this.label1.Text = "Điểm:";
            // 
            // lbKetQua
            // 
            this.lbKetQua.AutoSize = true;
            this.lbKetQua.Font = new System.Drawing.Font("Arial Narrow", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKetQua.ForeColor = System.Drawing.Color.Firebrick;
            this.lbKetQua.Location = new System.Drawing.Point(499, 373);
            this.lbKetQua.Name = "lbKetQua";
            this.lbKetQua.Size = new System.Drawing.Size(34, 42);
            this.lbKetQua.TabIndex = 4;
            this.lbKetQua.Text = "0";
            // 
            // f1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(718, 450);
            this.Controls.Add(this.lbKetQua);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btQuaySo);
            this.Controls.Add(this.groupBoxChon);
            this.Controls.Add(this.lb3);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb1);
            this.MinimizeBox = false;
            this.Name = "f1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Random number";
            this.groupBoxChon.ResumeLayout(false);
            this.groupBoxChon.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.GroupBox groupBoxChon;
        private System.Windows.Forms.Button btQuaySo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbKetQua;
        private System.Windows.Forms.RadioButton rd11;
        private System.Windows.Forms.RadioButton rb3;
    }
}

