﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTH2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Random Rand = new Random();
        int Ketqua = 0;


        private void buttonTiepTuc_Click(object sender, EventArgs e)
        {
            int so1 = Rand.Next(0, 10);
            int so2 = Rand.Next(1, 10);
            int Dau = Rand.Next(1, 5);
            
            lbSo1.Text = so1.ToString();
            lbSo2.Text = so2.ToString();

            if (Dau == 1)
            {
                lbDau.Text = "+";
                Ketqua = so1 + so2;
            }else if (Dau == 2)
            {
                lbDau.Text = "-";
                Ketqua = so1 - so2;
            }else if (Dau == 3)
            {
                lbDau.Text = "x";
                Ketqua = so1 * so2;
            }
            else
            {
                lbDau.Text = "/";
                Ketqua = so1 / so2;
            }          
        }

        private void buttonXem_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(textBoxTraLoi.Text);
                if (n == Ketqua)
                {
                    lbKetqua.Text = "Đúng rồi!";
                }
                else
                {
                    lbKetqua.Text = "Sai rồi! Kết quả là " + Ketqua.ToString();
                }
            }
            catch (FormatException)
            {
                lbKetqua.Text = "Ban phai nhap cau tra loi bang so";
            }
        }

        private void btSo0_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "0";
        }

        private void btSo1_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "1";
        }

        private void btSo2_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "2";
        }

        private void btSo3_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "3";
        }

        private void btSo4_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "4";
        }

        private void btSo5_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "5";
        }

        private void btSo6_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "6";
        }

        private void btSo7_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "7";
        }

        private void btSo8_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "8";
        }

        private void btSo9_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "9";
        }

        private void btDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btTru_Click(object sender, EventArgs e)
        {
            textBoxTraLoi.Text += "-";
        }
    }
}
