﻿
namespace BTH2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbSo1 = new System.Windows.Forms.Label();
            this.lbDau = new System.Windows.Forms.Label();
            this.lbSo2 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxTraLoi = new System.Windows.Forms.TextBox();
            this.buttonXem = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonTiepTuc = new System.Windows.Forms.Button();
            this.btSo0 = new System.Windows.Forms.Button();
            this.btSo1 = new System.Windows.Forms.Button();
            this.btSo2 = new System.Windows.Forms.Button();
            this.btSo3 = new System.Windows.Forms.Button();
            this.btSo4 = new System.Windows.Forms.Button();
            this.btTru = new System.Windows.Forms.Button();
            this.btSo5 = new System.Windows.Forms.Button();
            this.btSo7 = new System.Windows.Forms.Button();
            this.btSo6 = new System.Windows.Forms.Button();
            this.btSo9 = new System.Windows.Forms.Button();
            this.btSo8 = new System.Windows.Forms.Button();
            this.btDong = new System.Windows.Forms.Button();
            this.lbKetqua = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(586, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "CHƯƠNG TRÌNH GIÚP BÉ HỌC TOÁN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSo1
            // 
            this.lbSo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbSo1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbSo1.Location = new System.Drawing.Point(46, 85);
            this.lbSo1.Name = "lbSo1";
            this.lbSo1.Size = new System.Drawing.Size(106, 71);
            this.lbSo1.TabIndex = 1;
            this.lbSo1.Text = "0";
            this.lbSo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDau
            // 
            this.lbDau.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbDau.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDau.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbDau.Location = new System.Drawing.Point(240, 85);
            this.lbDau.Name = "lbDau";
            this.lbDau.Size = new System.Drawing.Size(106, 71);
            this.lbDau.TabIndex = 1;
            this.lbDau.Text = "+";
            this.lbDau.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSo2
            // 
            this.lbSo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbSo2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbSo2.Location = new System.Drawing.Point(434, 85);
            this.lbSo2.Name = "lbSo2";
            this.lbSo2.Size = new System.Drawing.Size(106, 71);
            this.lbSo2.TabIndex = 1;
            this.lbSo2.Text = "0";
            this.lbSo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(45, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Trả lời:";
            // 
            // textBoxTraLoi
            // 
            this.textBoxTraLoi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTraLoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTraLoi.Location = new System.Drawing.Point(167, 188);
            this.textBoxTraLoi.Name = "textBoxTraLoi";
            this.textBoxTraLoi.Size = new System.Drawing.Size(234, 31);
            this.textBoxTraLoi.TabIndex = 3;
            this.textBoxTraLoi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonXem
            // 
            this.buttonXem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonXem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonXem.Location = new System.Drawing.Point(429, 186);
            this.buttonXem.Name = "buttonXem";
            this.buttonXem.Size = new System.Drawing.Size(113, 36);
            this.buttonXem.TabIndex = 4;
            this.buttonXem.Text = "Xem";
            this.buttonXem.UseVisualStyleBackColor = true;
            this.buttonXem.Click += new System.EventHandler(this.buttonXem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Kết quả:";
            // 
            // buttonTiepTuc
            // 
            this.buttonTiepTuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTiepTuc.Location = new System.Drawing.Point(429, 249);
            this.buttonTiepTuc.Name = "buttonTiepTuc";
            this.buttonTiepTuc.Size = new System.Drawing.Size(113, 36);
            this.buttonTiepTuc.TabIndex = 4;
            this.buttonTiepTuc.Text = "Tiếp tục";
            this.buttonTiepTuc.UseVisualStyleBackColor = true;
            this.buttonTiepTuc.Click += new System.EventHandler(this.buttonTiepTuc_Click);
            // 
            // btSo0
            // 
            this.btSo0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo0.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo0.Location = new System.Drawing.Point(32, 308);
            this.btSo0.Name = "btSo0";
            this.btSo0.Size = new System.Drawing.Size(67, 52);
            this.btSo0.TabIndex = 5;
            this.btSo0.Text = "0";
            this.btSo0.UseVisualStyleBackColor = false;
            this.btSo0.Click += new System.EventHandler(this.btSo0_Click);
            // 
            // btSo1
            // 
            this.btSo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo1.Location = new System.Drawing.Point(123, 308);
            this.btSo1.Name = "btSo1";
            this.btSo1.Size = new System.Drawing.Size(67, 52);
            this.btSo1.TabIndex = 5;
            this.btSo1.Text = "1";
            this.btSo1.UseVisualStyleBackColor = false;
            this.btSo1.Click += new System.EventHandler(this.btSo1_Click);
            // 
            // btSo2
            // 
            this.btSo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo2.Location = new System.Drawing.Point(214, 308);
            this.btSo2.Name = "btSo2";
            this.btSo2.Size = new System.Drawing.Size(67, 52);
            this.btSo2.TabIndex = 5;
            this.btSo2.Text = "2";
            this.btSo2.UseVisualStyleBackColor = false;
            this.btSo2.Click += new System.EventHandler(this.btSo2_Click);
            // 
            // btSo3
            // 
            this.btSo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo3.Location = new System.Drawing.Point(305, 308);
            this.btSo3.Name = "btSo3";
            this.btSo3.Size = new System.Drawing.Size(67, 52);
            this.btSo3.TabIndex = 5;
            this.btSo3.Text = "3";
            this.btSo3.UseVisualStyleBackColor = false;
            this.btSo3.Click += new System.EventHandler(this.btSo3_Click);
            // 
            // btSo4
            // 
            this.btSo4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo4.Location = new System.Drawing.Point(396, 308);
            this.btSo4.Name = "btSo4";
            this.btSo4.Size = new System.Drawing.Size(67, 52);
            this.btSo4.TabIndex = 5;
            this.btSo4.Text = "4";
            this.btSo4.UseVisualStyleBackColor = false;
            this.btSo4.Click += new System.EventHandler(this.btSo4_Click);
            // 
            // btTru
            // 
            this.btTru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btTru.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTru.Location = new System.Drawing.Point(487, 308);
            this.btTru.Name = "btTru";
            this.btTru.Size = new System.Drawing.Size(67, 52);
            this.btTru.TabIndex = 5;
            this.btTru.Text = "-";
            this.btTru.UseVisualStyleBackColor = false;
            this.btTru.Click += new System.EventHandler(this.btTru_Click);
            // 
            // btSo5
            // 
            this.btSo5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo5.Location = new System.Drawing.Point(32, 376);
            this.btSo5.Name = "btSo5";
            this.btSo5.Size = new System.Drawing.Size(67, 52);
            this.btSo5.TabIndex = 5;
            this.btSo5.Text = "5";
            this.btSo5.UseVisualStyleBackColor = false;
            this.btSo5.Click += new System.EventHandler(this.btSo5_Click);
            // 
            // btSo7
            // 
            this.btSo7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo7.Location = new System.Drawing.Point(214, 376);
            this.btSo7.Name = "btSo7";
            this.btSo7.Size = new System.Drawing.Size(67, 52);
            this.btSo7.TabIndex = 5;
            this.btSo7.Text = "7";
            this.btSo7.UseVisualStyleBackColor = false;
            this.btSo7.Click += new System.EventHandler(this.btSo7_Click);
            // 
            // btSo6
            // 
            this.btSo6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo6.Location = new System.Drawing.Point(123, 376);
            this.btSo6.Name = "btSo6";
            this.btSo6.Size = new System.Drawing.Size(67, 52);
            this.btSo6.TabIndex = 5;
            this.btSo6.Text = "6";
            this.btSo6.UseVisualStyleBackColor = false;
            this.btSo6.Click += new System.EventHandler(this.btSo6_Click);
            // 
            // btSo9
            // 
            this.btSo9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo9.Location = new System.Drawing.Point(396, 376);
            this.btSo9.Name = "btSo9";
            this.btSo9.Size = new System.Drawing.Size(67, 52);
            this.btSo9.TabIndex = 5;
            this.btSo9.Text = "9";
            this.btSo9.UseVisualStyleBackColor = false;
            this.btSo9.Click += new System.EventHandler(this.btSo9_Click);
            // 
            // btSo8
            // 
            this.btSo8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btSo8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSo8.Location = new System.Drawing.Point(305, 376);
            this.btSo8.Name = "btSo8";
            this.btSo8.Size = new System.Drawing.Size(67, 52);
            this.btSo8.TabIndex = 5;
            this.btSo8.Text = "8";
            this.btSo8.UseVisualStyleBackColor = false;
            this.btSo8.Click += new System.EventHandler(this.btSo8_Click);
            // 
            // btDong
            // 
            this.btDong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDong.Location = new System.Drawing.Point(487, 376);
            this.btDong.Name = "btDong";
            this.btDong.Size = new System.Drawing.Size(67, 52);
            this.btDong.TabIndex = 5;
            this.btDong.Text = "<-";
            this.btDong.UseVisualStyleBackColor = false;
            this.btDong.Click += new System.EventHandler(this.btDong_Click);
            // 
            // lbKetqua
            // 
            this.lbKetqua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbKetqua.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbKetqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKetqua.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbKetqua.Location = new System.Drawing.Point(167, 249);
            this.lbKetqua.Name = "lbKetqua";
            this.lbKetqua.Size = new System.Drawing.Size(234, 36);
            this.lbKetqua.TabIndex = 1;
            this.lbKetqua.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 450);
            this.Controls.Add(this.btDong);
            this.Controls.Add(this.btTru);
            this.Controls.Add(this.btSo8);
            this.Controls.Add(this.btSo3);
            this.Controls.Add(this.btSo9);
            this.Controls.Add(this.btSo4);
            this.Controls.Add(this.btSo6);
            this.Controls.Add(this.btSo1);
            this.Controls.Add(this.btSo7);
            this.Controls.Add(this.btSo2);
            this.Controls.Add(this.btSo5);
            this.Controls.Add(this.btSo0);
            this.Controls.Add(this.buttonTiepTuc);
            this.Controls.Add(this.buttonXem);
            this.Controls.Add(this.textBoxTraLoi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbSo2);
            this.Controls.Add(this.lbKetqua);
            this.Controls.Add(this.lbDau);
            this.Controls.Add(this.lbSo1);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbSo1;
        private System.Windows.Forms.Label lbDau;
        private System.Windows.Forms.Label lbSo2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxTraLoi;
        private System.Windows.Forms.Button buttonXem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonTiepTuc;
        private System.Windows.Forms.Button btSo0;
        private System.Windows.Forms.Button btSo1;
        private System.Windows.Forms.Button btSo2;
        private System.Windows.Forms.Button btSo3;
        private System.Windows.Forms.Button btSo4;
        private System.Windows.Forms.Button btTru;
        private System.Windows.Forms.Button btSo5;
        private System.Windows.Forms.Button btSo7;
        private System.Windows.Forms.Button btSo6;
        private System.Windows.Forms.Button btSo9;
        private System.Windows.Forms.Button btSo8;
        private System.Windows.Forms.Button btDong;
        private System.Windows.Forms.Label lbKetqua;
    }
}