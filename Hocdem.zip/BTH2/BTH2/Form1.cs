﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTH2
{
    public partial class f1 : Form
    {
        public f1()
        {
            InitializeComponent();
        }

        Random Rand = new Random();
        int Diem = 0;


        private void btQuaySo_Click(object sender, EventArgs e)
        {
            int so1 = Rand.Next(1, 7);
            int so2 = Rand.Next(1, 7);
            int so3 = Rand.Next(1, 7);

            lb1.Text = so1.ToString();
            lb2.Text = so2.ToString();
            lb3.Text = so3.ToString();


            if (rb3.Checked)
            {
                if ((so1 + so2 + so3) <= 10)
                    Diem += 10;
                else
                    Diem -= 10;
            }
            else
            {
                if ((so1 + so2 + so3) <= 10)
                    Diem -= 10;
                else
                    Diem += 10;
            }

            lbKetQua.Text = Diem.ToString();
        }

    }
}
