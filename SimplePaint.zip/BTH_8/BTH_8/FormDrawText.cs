﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
namespace BTH_8
{
    public partial class FormDrawText : Form
    {
        String sText = "HELLO";

        public FormDrawText()
        {
            InitializeComponent();
        }

        private void FormDrawText_Paint(object sender, PaintEventArgs e)
        {
            Font font = new Font("Arial", 48, FontStyle.Bold);
            StringFormat fm = new StringFormat();
            fm.Alignment = StringAlignment.Far;
            e.Graphics.DrawString(sText, font,Brushes.Green, ClientRectangle,fm);

            Image img = Image.FromFile("Hoahong.png");
            TextureBrush tbr = new TextureBrush(img);
            fm.Alignment = StringAlignment.Near;
            fm.LineAlignment = StringAlignment.Far;
            e.Graphics.DrawString(sText, font, tbr, ClientRectangle, fm);

            HatchBrush hbr = new HatchBrush(HatchStyle.Cross, Color.Red, Color.Yellow);
            fm.FormatFlags = StringFormatFlags.DirectionVertical;
            fm.LineAlignment = StringAlignment.Near;
            e.Graphics.DrawString(sText, font, hbr, ClientRectangle, fm);

            LinearGradientBrush lbr = new LinearGradientBrush(new Rectangle(0, 0, 10, 10), Color.DarkBlue, Color.White,45);
            fm.LineAlignment = StringAlignment.Far;
            fm.Alignment = StringAlignment.Far;
            e.Graphics.DrawString(sText, font, lbr, ClientRectangle, fm);
        }

        private void FormDrawText_SizeChanged(object sender, EventArgs e)
        {
            Invalidate();
        }
    }
}
