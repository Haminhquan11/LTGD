﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
namespace BTH_8
{
    public partial class FormDrawImage : Form
    {
        public FormDrawImage()
        {
            InitializeComponent();
        }

        private void FormDrawImage_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rc1 = new Rectangle(0, 0, ClientRectangle.Width / 2, ClientRectangle.Height / 2);
            Rectangle rc2 = new Rectangle(0, ClientRectangle.Height / 2, ClientRectangle.Width / 2, ClientRectangle.Height / 2);
            Rectangle rc3 = new Rectangle(ClientRectangle.Width / 2, 0, ClientRectangle.Width / 2, ClientRectangle.Height);
            DrawImage(rc1, e.Graphics);
            DrawText(rc2, e.Graphics);
            DrawPolygon(rc3, e.Graphics);
            Pen pen = new Pen(Color.Blue, 3);
            e.Graphics.DrawRectangles(pen, new Rectangle[] { rc1, rc2, rc3 });

        }

        void DrawImage(Rectangle rc, Graphics g)
        {
            Image img = Image.FromFile("bosua.jpg");
            g.DrawImage(img, rc);
            Color color = Color.FromArgb(100, 255, 255, 0);
            SolidBrush br = new SolidBrush(color);
            Font font = new Font("Arial", 16, FontStyle.Bold | FontStyle.Italic);
            StringFormat fm = new StringFormat();
            fm.LineAlignment = StringAlignment.Far;
            g.DrawString("Anita", font, br, rc, fm);
        }

        void DrawText(Rectangle rc, Graphics g)
        {
            LinearGradientBrush br1 = new LinearGradientBrush(rc, Color.Black, Color.White, 45);
            g.FillRectangle(br1, rc);
            LinearGradientBrush br2 = new LinearGradientBrush(new Rectangle(0, 0, 10, 10), Color.Red, Color.Yellow, 45);
            Font font = new Font("Arial", 48, FontStyle.Bold | FontStyle.Italic);
            StringFormat fm = new StringFormat();
            fm.LineAlignment = StringAlignment.Center;
            fm.Alignment = StringAlignment.Center;
            g.DrawString("HELLO", font, br2, rc, fm);
        }

        void DrawPolygon(Rectangle rc, Graphics g)
        {
            Point[] arrP =
            {
                new Point(rc.Left,rc.Height/4),
                new Point(rc.Left+rc.Width/2,rc.Top),
                new Point(rc.Left+rc.Width,rc.Height/4),
                new Point(rc.Left+rc.Width/2,rc.Height)
            };
            GraphicsPath path = new GraphicsPath();
            path.AddPolygon(arrP);
            PathGradientBrush br = new PathGradientBrush(path);
            br.CenterColor = Color.White;
            br.SurroundColors = new Color[] { Color.Yellow, Color.Red, Color.Cyan, Color.Green };
            g.FillPolygon(br, arrP);
        }

        private void FormDrawImage_SizeChanged(object sender, EventArgs e)
        {
            Invalidate();
        }
    }
}
